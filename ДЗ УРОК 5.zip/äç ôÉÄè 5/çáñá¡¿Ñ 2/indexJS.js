function cell(number, letter, player) {
	var newDiv = document.createElement("div");
	chessBoard.appendChild(newDiv);
	newDiv.textContent = letter;
	if (player == 1) {
		newDiv.style.transform = "rotate(180deg)";
	}
	newDiv.style.fontSize = "10vh";
	newDiv.style.lineHeight = "10vh";
	newDiv.style.textAlign = "center";
	newDiv.style.color = "#A9A9A9";
	newDiv.style.width = "10vh";
	newDiv.style.height = "10vh";
	newDiv.style.display = "inline-block";
	if (number % 2 == 0) {
		newDiv.style.backgroundColor = "#000";
	} else {
		newDiv.style.backgroundColor = "#fff";
	}
}
function firstLine(player, number) {
	cell(number, "С", player);
	cell((number+=1), "К", player);
	cell((number+=1), "Л", player);
	cell((number+=1), "К", player);
	cell((number+=1), "Ф", player);
	cell((number+=1), "Л", player);
	cell((number+=1), "К", player);
	cell((number+=1), "С", player);
}
firstLine(1, 1);
secondLine(1, 2);
function secondLine(player, number) {
	for (var i = number; i != (number + 8); i++) {
		cell(i, "П", player);
	}
}
function oddLine() {
	for(var i = 2; i != 10; i++) {
		cell(i);
	}
}
function evenLine() {
	for(var i = 1; i != 9; i++) {
		cell(i);
	}
}
for(var i = 2; i != 6; i++) {
	if (i % 2 == 0) {
		evenLine();
	} else {
		oddLine();
	}
}
secondLine(2, 1);
firstLine(2, 2);
function letterTop(src, number) {
	var newImg = document.createElement("img")
	chessBoard.appendChild(newImg);
	newImg.setAttribute("src", src);
	newImg.style.width = "5vh";
	newImg.style.height = "5vh";
	newImg.style.position = "absolute";
	newImg.style.left = 'calc(((100% - 80vh) / 2) + 3vh + ' + (number - 1) * 10 +'vh)';
	newImg.style.top = "47px";
	newImg.style.transform = "rotate(180deg)";
}
function letterBottom(src, number) {
	var newImg = document.createElement("img")
	chessBoard.appendChild(newImg);
	newImg.setAttribute("src", src);
	newImg.style.width = "5vh";
	newImg.style.height = "5vh";
	newImg.style.position = "absolute";
	newImg.style.left = 'calc(((100% - 80vh) / 2) + 3vh + ' + (number - 1) * 10 +'vh)';
	newImg.style.top = "calc(55px + 85vh)";
}
function numberLeft(src, number) {
	var newImg = document.createElement("img")
	chessBoard.appendChild(newImg);
	newImg.setAttribute("src", src);
	newImg.style.width = "5vh";
	newImg.style.height = "5vh";
	newImg.style.position = "absolute";
	newImg.style.left = 'calc((100% - 90vh) / 2)';
	newImg.style.top = 'calc(47px + 8vh + ' + (number - 1) * 10 + 'vh)';
}
function numberRight(src, number) {
	var newImg = document.createElement("img")
	chessBoard.appendChild(newImg);
	newImg.setAttribute("src", src);
	newImg.style.width = "5vh";
	newImg.style.height = "5vh";
	newImg.style.position = "absolute";
	newImg.style.transform = "rotate(180deg)";
	newImg.style.right = 'calc((100% - 90vh - 16px) / 2)';
	newImg.style.top = 'calc(47px + 8vh + ' + (number - 1) * 10 + 'vh)';
}
letterTop("Photo/letter-a.svg", 1);
letterTop("Photo/letter-b.svg", 2);
letterTop("Photo/letter-c.svg", 3);
letterTop("Photo/letter-d.svg", 4);
letterTop("Photo/letter-e.svg", 5);
letterTop("Photo/letter-f.svg", 6);
letterTop("Photo/letter-g.svg", 7);
letterTop("Photo/letter-h.svg", 8);
letterBottom("Photo/letter-a.svg", 1);
letterBottom("Photo/letter-b.svg", 2);
letterBottom("Photo/letter-c.svg", 3);
letterBottom("Photo/letter-d.svg", 4);
letterBottom("Photo/letter-e.svg", 5);
letterBottom("Photo/letter-f.svg", 6);
letterBottom("Photo/letter-g.svg", 7);
letterBottom("Photo/letter-h.svg", 8);
numberLeft("Photo/one.svg", 1);
numberLeft("Photo/two.svg", 2);
numberLeft("Photo/three.svg", 3);
numberLeft("Photo/four.svg", 4);
numberLeft("Photo/five.svg", 5);
numberLeft("Photo/six.svg", 6);
numberLeft("Photo/seven.svg", 7);
numberLeft("Photo/eight.svg", 8);
numberRight("Photo/one.svg", 1);
numberRight("Photo/two.svg", 2);
numberRight("Photo/three.svg", 3);
numberRight("Photo/four.svg", 4);
numberRight("Photo/five.svg", 5);
numberRight("Photo/six.svg", 6);
numberRight("Photo/seven.svg", 7);
numberRight("Photo/eight.svg", 8);