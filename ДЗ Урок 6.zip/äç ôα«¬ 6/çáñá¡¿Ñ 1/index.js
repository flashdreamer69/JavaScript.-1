var newImgBig = document.createElement("img")
imgBig.appendChild(newImgBig);
newImgBig.setAttribute("src", "Photo/4.jpg");
newImgBig.style.height = "70vh";
newImgBig.style.display = "block";
newImgBig.style.margin = "auto";
newImgBig.style.marginTop = "10vh";
var imgName = {
	img1: "Photo/1.jpg",
	img2: "Photo/2.jpg",
	img3: "Photo/3.jpg"
}
function checkForError(scr) {
	var answer;
	for (var i in imgName) {
		if (imgName[i] == scr) {
			return true;
			break;
		} else {
			answer = false;
		}
	}
	return answer;
}

function sliderImgBig(src) {
	if (checkForError(src)) {
		document.getElementById("imgBig").children[0].removeAttribute("scr");
		newImgBig.setAttribute("src", src);
	} else {
		document.getElementById("imgBig").children[0].removeAttribute("scr")
		newImgBig.setAttribute("src", "Photo/5.png");
	}
}