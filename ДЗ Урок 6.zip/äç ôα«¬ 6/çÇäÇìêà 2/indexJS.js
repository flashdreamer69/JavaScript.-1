var allPrice = 0;
var i = 0;
var idMore = ["basketGoods1", "basketGoods2", "basketGoods3"];
function additionOfGoods(text, scr, price) {
	var newImg = document.createElement("img")
	document.getElementById(idMore[i]).appendChild(newImg);
	newImg.setAttribute("src", scr);
	var newP = document.createElement("p")
	document.getElementById(idMore[i]).appendChild(newP);
	newP.textContent = text;
	i+=1;
	allPrice += price;
	document.getElementById("textPrice").textContent = ("Цена товаров: " + allPrice + " руб");
}